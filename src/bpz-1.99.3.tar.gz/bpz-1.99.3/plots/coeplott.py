from coeplot import *
thick()
