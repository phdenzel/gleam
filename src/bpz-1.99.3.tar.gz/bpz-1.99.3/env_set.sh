#!/bin/bash

thisPath="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

export BPZPATH="${thisPath}"
export PYTHONPATH=$PYTHONPATH:$BPZPATH
alias bpz="python $BPZPATH/bpz.py"
env;
