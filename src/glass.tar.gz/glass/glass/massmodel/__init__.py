'''
   #------------------------------------------------------------------------
   # __init__.py | version 0.0 | Justin Read 2009 
   #------------------------------------------------------------------------
'''

from __future__ import division
from numfuncs import *
from datafile import *



